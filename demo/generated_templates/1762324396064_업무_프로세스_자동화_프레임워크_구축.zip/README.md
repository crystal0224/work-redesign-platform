# 업무 프로세스 자동화 프레임워크 구축 자동화 패키지

## 개요
- **작업명**: 업무 프로세스 자동화 프레임워크 구축
- **설명**: 현재 수동으로 처리하는 반복 업무들을 자동화할 수 있는 체계적인 프레임워크를 구축합니다.
- **우선순위**: HIGH
- **예상 시간**: 32시간
- **생성일**: 2025. 11. 5. 오후 3:33:16

## 패키지 구성

### 📝 프롬프트 템플릿 (prompts/)
- analysis_prompt.md: 분석 에이전트용 프롬프트
- task_prompt.md: 작업 에이전트용 프롬프트
- coordination_prompt.md: 코디네이션 에이전트용 프롬프트
- optimization_prompt.md: 최적화 에이전트용 프롬프트

### 🔄 워크플로우 템플릿 (workflows/)
- n8n_workflow.json: n8n 자동화 워크플로우

### 💻 코드 스니펫 (code/)
- 업무_프로세스_자동화_프레임워크_구축.py: Python 자동화 스크립트
- 업무_프로세스_자동화_프레임워크_구축.js: JavaScript 자동화 스크립트
- 업무_프로세스_자동화_프레임워크_구축.sql: SQL 쿼리 및 뷰

## 사용 가이드

### 1. 프롬프트 템플릿 사용법
1. Claude, ChatGPT 등 AI 도구에 프롬프트 복사
2. {변수명} 부분을 실제 값으로 치환
3. 컨텍스트에 맞게 내용 조정

### 2. n8n 워크플로우 설정
1. n8n에서 "Import from JSON" 선택
2. workflows/n8n_workflow.json 파일 업로드
3. 각 노드의 설정값 확인 및 조정

### 3. 코드 실행
#### Python
```bash
pip install pandas
python code/업무_프로세스_자동화_프레임워크_구축.py
```

#### JavaScript
```bash
node code/업무_프로세스_자동화_프레임워크_구축.js
```

---
*이 패키지는 SK Work Redesign Platform에서 자동 생성되었습니다.*