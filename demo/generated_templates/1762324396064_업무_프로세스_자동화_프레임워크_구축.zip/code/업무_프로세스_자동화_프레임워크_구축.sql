-- 업무 프로세스 자동화 프레임워크 구축 - SQL 자동화 스크립트
-- 생성일: 2025-11-05T06:33:16.112Z
-- 우선순위: HIGH
-- 예상 시간: 32시간

-- 1. 기본 데이터 조회 쿼리
SELECT
    id,
    created_at,
    status,
    priority,
    value,
    category,
    CASE
        WHEN value > 1000 THEN 'high'
        WHEN value > 100 THEN 'medium'
        ELSE 'low'
    END as classification
FROM 업무_프로세스_자동화_프레임워크_구축_data
WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
ORDER BY priority DESC, created_at DESC;

-- 2. 집계 및 통계 쿼리
WITH statistics AS (
    SELECT
        COUNT(*) as total_records,
        AVG(value) as avg_value,
        MAX(value) as max_value,
        MIN(value) as min_value,
        COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_count,
        COUNT(CASE WHEN priority = 'HIGH' THEN 1 END) as high_priority_count
    FROM 업무_프로세스_자동화_프레임워크_구축_data
    WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
)
SELECT
    *,
    ROUND((completed_count::DECIMAL / total_records) * 100, 2) as completion_rate,
    ROUND((high_priority_count::DECIMAL / total_records) * 100, 2) as high_priority_rate
FROM statistics;

-- 3. 데이터 처리 및 업데이트
UPDATE 업무_프로세스_자동화_프레임워크_구축_data
SET
    status = 'processed',
    processed_at = CURRENT_TIMESTAMP,
    classification = CASE
        WHEN value > 1000 THEN 'high'
        WHEN value > 100 THEN 'medium'
        ELSE 'low'
    END
WHERE status = 'pending'
AND created_at >= CURRENT_DATE - INTERVAL '1 day';